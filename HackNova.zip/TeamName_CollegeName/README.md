# GlucoTwin - Digital Twin for Type 2 Diabetes

**Team:** <Team name> | **College / incubator:** <College name>
**Members:** <Name 1 (leader)>, <Name 2>, ... | **Contact:** <leader email>
**Challenge:** Happiest Health Digital Twin Challenge - Reimagining and Reforming Healthcare in India Summit 2026

## 1. Problem statement and use case
India has one of the world's largest Type 2 Diabetes populations, yet patients are usually reviewed only every few months, so glucose spikes between visits go unnoticed.
**GlucoTwin** is a proof-of-concept virtual patient that fuses static EHR data with wearable/CGM time series to predict, **2 hours ahead, whether glucose will cross 180 mg/dL**, and lets a doctor run "what if" scenarios (meal, walk, sleep).

Task: given the last 6 h of glucose, heart rate, steps and sleep (5-min grid) plus static EHR features, predict whether glucose goes above 180 mg/dL within 2 h. Windows already above 180 are excluded (we predict *onset*).

## 2. Data (synthetic only: DPDP / HIPAA safe)
No real patient data is used. `src/data_gen.py` simulates 60 patients x 14 days:
- **Static EHR:** age, sex, BMI, HbA1c, fasting glucose, metformin, insulin, hypertension, family history.
- **Dynamic stream:** CGM glucose, heart rate, steps, asleep flag, last-night sleep hours (5-min).
- Rule-based physiology: meals raise glucose (scaled by insulin resistance), walking lowers it, short sleep raises insulin resistance, stress raises glucose and HR; CGM dropouts are injected.
- **Limitation:** relationships are built into the simulator, so absolute metrics are optimistic. The pipeline is designed so real open datasets (e.g. CGMacros, Shanghai T2DM, Synthea EHRs) can replace the generator: output the same two CSVs in `data/synthetic/` (schema in `src/data_gen.py`).

## 3. Technical stack
Python, NumPy/Pandas, scikit-learn, PyTorch (LSTM + MLP fusion network), Matplotlib, Streamlit + Plotly.

**Model:** LSTM over the 6 h dynamic window + MLP over the static vector -> concatenate -> dense head -> spike probability. Trained with `BCEWithLogitsLoss(pos_weight)`, early stopping on validation AUROC, decision threshold chosen on validation F1. Split **by patient** (70/15/15), normalisation from train only.

## 4. How to run (from a clean machine)
```bash
git clone <your-repo-url> && cd TeamName_CollegeName
python -m venv .venv && source .venv/bin/activate      # Windows: .venv\Scripts\activate
pip install -r requirements.txt
sh run_all.sh                                          # or run the 4 commands inside it one by one
streamlit run app/streamlit_app.py
```
Pre-generated data is included, so you can also skip straight to `python -m src.data_prep` if you want.

## 5. Results (test set = 9 unseen patients)
See `results/ablation.md`, `results/ablation.png`, `results/importance.png`.

| Model | AUROC | AUPRC | F1 | Lead time (min) | False alarms/day |
|---|---|---|---|---|---|
| Baseline A: persistence rule | 0.629 | 0.225 | 0.264 | 54.7 | 16.4 |
| Baseline B: GBM (all features) | 0.916 | 0.670 | 0.634 | 58.6 | 3.15 |
| CGM only (LSTM) | 0.920 | 0.626 | 0.608 | 57.5 | 3.71 |
| CGM + wearables (LSTM) | 0.916 | 0.636 | 0.600 | 56.5 | 3.68 |
| CGM + static EHR (LSTM) | 0.938 | 0.711 | 0.653 | 57.9 | 3.26 |
| **Full fusion (LSTM + EHR)** | 0.935 | 0.684 | 0.649 | 58.3 | 3.25 |

**Honest reading:** adding static EHR clearly helps over CGM alone (AUPRC 0.63 -> 0.68-0.71, fewer false alarms). Wearable channels add little in this synthetic setup (single seed, 9 test patients, so differences of ~0.01 are within noise). Lead time = mean minutes between the alert and the actual threshold crossing for correctly flagged windows. Next step: run several seeds and report mean +/- std.

## 6. Digital-twin layer and dashboard
`src/twin_simulator.py` keeps a patient state, rolls it forward 30 min under a scenario (meal carbs, walk minutes, last-night sleep) using rule-based glucose/HR/step responses, and re-queries the model. Dashboard tabs: **Live twin** (CGM trace, risk gauge, alert, reasons), **What-if simulator**, **7-day trends** (time in range). Scenario effects are approximate and not clinically validated.

## 7. Ethics and limitations
Research prototype, not a diagnostic or treatment device. Synthetic data only. Simulated physiology, small cohort, no external validation, no bias audit across populations. Real deployment would need clinical validation and regulatory review.

## 8. Deliverables
- Video (20+ min): <paste unlisted YouTube link>
- Architecture diagram: `docs/architecture.pdf`
- Presentation: `docs/presentation.pdf` (add your slides)
- License: MIT (`LICENSE`)

## 9. Repo layout
```
src/data_gen.py  data_prep.py  models.py  train.py  run_ablation.py  explain.py  twin_simulator.py  make_architecture.py
app/streamlit_app.py     data/synthetic/*.csv     results/*     docs/architecture.pdf
```
