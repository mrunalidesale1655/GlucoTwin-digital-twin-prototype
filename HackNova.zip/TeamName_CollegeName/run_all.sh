#!/bin/sh
set -e
python -m src.data_gen          # 1. synthetic EHR + wearable data
python -m src.data_prep         # 2. clean, window, split by patient, normalise
python -m src.run_ablation      # 3. baselines + 4 deep variants + importance (takes ~10-15 min on CPU)
python -m src.make_architecture # 4. docs/architecture.pdf
echo "Done. Launch the dashboard:  streamlit run app/streamlit_app.py"
