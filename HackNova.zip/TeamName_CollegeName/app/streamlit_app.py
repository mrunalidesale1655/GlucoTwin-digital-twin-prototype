"""GlucoTwin doctor dashboard.  Run:  streamlit run app/streamlit_app.py"""
import json, sys
from pathlib import Path
import numpy as np
import pandas as pd
import plotly.graph_objects as go
import streamlit as st

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from src.config import *
from src.data_prep import clean_patient, load_raw
from src.twin_simulator import PatientTwin

st.set_page_config(page_title="GlucoTwin", page_icon="🩺", layout="wide")
st.title("🩺 GlucoTwin - Digital Twin for Type 2 Diabetes")
st.caption("Proof-of-concept on SYNTHETIC data. Research prototype - not a medical device.")

if not (MODELS / "glucotwin_full.pt").exists():
    st.error("Model not found. Run the pipeline first:  python -m src.data_gen && "
             "python -m src.data_prep && python -m src.run_ablation")
    st.stop()


@st.cache_resource
def load_twin():
    return PatientTwin()


@st.cache_data
def load_data():
    wear, ehr = load_raw()
    meta = json.load(open(PROC / "meta.json"))
    return wear, ehr, meta["split"]["test"]


twin = load_twin()
wear, ehr, test_pids = load_data()

pid = st.sidebar.selectbox("Virtual patient (held-out test set)", test_pids)
df = clean_patient(wear[wear.patient_id == pid])
static = ehr.loc[pid, STATIC_COLS].to_numpy(np.float32)
prof = ehr.loc[pid]

day = st.sidebar.slider("Replay day", 1, int(len(df) / STEPS_PER_DAY) - 1, 5)
hour = st.sidebar.slider("Time of day (h)", 0.0, 23.5, 12.0, 0.5)
end = int(day * STEPS_PER_DAY + hour * 12)
window = df[DYN_COLS].iloc[end - WINDOW:end].to_numpy(np.float32)
future = df["glucose"].iloc[end:end + HORIZON]

st.sidebar.markdown("---")
st.sidebar.subheader("Patient profile")
st.sidebar.write(f"**{pid}** - age {int(prof.age)}, {'F' if prof.sex else 'M'}, BMI {prof.bmi}")
st.sidebar.write(f"HbA1c **{prof.hba1c}%**, fasting {prof.fasting_glucose} mg/dL")
st.sidebar.write("Meds: " + ", ".join([m for m, f in [("metformin", prof.metformin), ("insulin", prof.insulin)] if f]) or "none")
st.sidebar.write(f"Hypertension: {'yes' if prof.hypertension else 'no'} | Family hx: {'yes' if prof.family_history else 'no'}")

tab1, tab2, tab3 = st.tabs(["Live twin", "What-if simulator", "7-day trends"])

with tab1:
    p = twin.risk(window, static)
    cur = float(window[-1, 0])
    c1, c2 = st.columns([2, 1])
    with c1:
        past = df.iloc[max(0, end - 288):end]
        fig = go.Figure()
        fig.add_trace(go.Scatter(x=(past.t - end) / 12, y=past.glucose, name="CGM (past)", line=dict(color="#1f6fd1")))
        fig.add_hline(y=THRESH, line_dash="dash", line_color="red", annotation_text="180 mg/dL")
        fig.update_layout(height=340, xaxis_title="hours before now", yaxis_title="mg/dL", margin=dict(t=20))
        st.plotly_chart(fig, width="stretch")
        st.caption(f"Replay only - what actually happens in the next 2 h: peak {future.max():.0f} mg/dL")
    with c2:
        g = go.Figure(go.Indicator(mode="gauge+number", value=p * 100, number={"suffix": "%"},
              title={"text": "Spike risk (next 2 h)"},
              gauge={"axis": {"range": [0, 100]}, "bar": {"color": "#333"},
                     "steps": [{"range": [0, 30], "color": "#c8f0c8"}, {"range": [30, 60], "color": "#fff0b3"},
                               {"range": [60, 100], "color": "#f7c4c4"}]}))
        g.update_layout(height=260, margin=dict(t=40, b=0)); st.plotly_chart(g, width="stretch")
        if cur > THRESH:
            st.warning(f"Glucose already {cur:.0f} mg/dL (> {THRESH:.0f}). Model predicts onset only.")
        elif p >= twin.threshold:
            st.error(f"ALERT: high spike risk ({p:.0%}).")
        else:
            st.success(f"No alert ({p:.0%}).")
    st.subheader("Why? (heuristic summary of the inputs)")
    slope = window[-1, 0] - window[-7, 0]
    reasons = []
    if slope > 15: reasons.append(f"Glucose rising fast: +{slope:.0f} mg/dL in the last 30 min.")
    if cur > 140: reasons.append(f"Current glucose is elevated ({cur:.0f} mg/dL).")
    if window[-12:, 2].sum() < 300: reasons.append("Very little movement in the last hour.")
    if window[-1, 6] < 6: reasons.append(f"Short sleep last night ({window[-1, 6]:.1f} h).")
    if prof.hba1c > 8: reasons.append(f"Poor long-term control (HbA1c {prof.hba1c}%).")
    st.write("\n".join(f"- {r}" for r in reasons) if reasons else "- No strong risk drivers in the recent window.")
    st.caption("See results/importance.png for the model's global feature importance.")

with tab2:
    st.write("Roll the patient forward 30 minutes under a scenario and compare predicted risk.")
    a, b, c = st.columns(3)
    carbs = a.slider("Meal now (g carbs)", 0, 150, 90, 5)
    walk = b.slider("Walk (minutes)", 0, 30, 0, 5)
    sleep = c.slider("Last night's sleep (h)", 3.0, 9.0, float(window[-1, 6]), 0.5)
    r = twin.what_if(window, static, carbs, walk, sleep)
    m1, m2 = st.columns(2)
    m1.metric("Baseline risk (do nothing)", f"{r['baseline_risk']:.0%}")
    m2.metric("Scenario risk", f"{r['scenario_risk']:.0%}", f"{(r['scenario_risk'] - r['baseline_risk']) * 100:+.0f} pts",
              delta_color="inverse")
    f2 = go.Figure()
    f2.add_trace(go.Scatter(y=r["baseline_glucose"], name="Baseline", line=dict(color="gray")))
    f2.add_trace(go.Scatter(y=r["scenario_glucose"], name="Scenario", line=dict(color="#d9534f")))
    f2.update_layout(height=300, xaxis_title="5-min steps ahead", yaxis_title="mg/dL (rule-based projection)")
    st.plotly_chart(f2, width="stretch")
    st.caption("What-if effects use simplified rule-based responses plus the learned model. Not clinically validated.")

with tab3:
    d = df.copy(); d["day"] = d.t // STEPS_PER_DAY
    d = d.dropna(subset=["glucose"])
    daily = d.groupby("day").glucose.agg(
        TIR=lambda x: ((x >= 70) & (x <= 180)).mean() * 100, Mean="mean", Max="max").round(1)
    st.write("Time-in-range (70-180 mg/dL), daily mean and peak glucose")
    st.bar_chart(daily["TIR"])
    st.dataframe(daily.tail(7))
