"""Draws docs/architecture.pdf (+ .png). Run: python -m src.make_architecture"""
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch
from .config import ROOT


def box(ax, x, y, w, h, text, color):
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.02", fc=color, ec="#333", lw=1.2))
    ax.text(x + w / 2, y + h / 2, text, ha="center", va="center", fontsize=9)


def arrow(ax, x1, y1, x2, y2):
    ax.annotate("", xy=(x2, y2), xytext=(x1, y1), arrowprops=dict(arrowstyle="->", lw=1.5))


fig, ax = plt.subplots(figsize=(13, 6)); ax.set_xlim(0, 13); ax.set_ylim(0, 6); ax.axis("off")
ax.set_title("GlucoTwin - Digital Twin architecture (Type 2 Diabetes)", fontsize=13, weight="bold")
box(ax, .2, 3.8, 2.4, 1.2, "Wearable / CGM stream\n(glucose, HR, steps, sleep)\nsimulated or open data", "#d9ecff")
box(ax, .2, 1.0, 2.4, 1.2, "Static EHR\n(age, BMI, HbA1c, meds,\ncomorbidities)\nsynthetic (Synthea-style)", "#ffe9cc")
box(ax, 3.3, 3.8, 2.2, 1.2, "Ingestion & cleaning\nresample 5 min,\ngap fill, time features", "#e8e8e8")
box(ax, 3.3, 1.0, 2.2, 1.2, "Static feature store\nstandardised vector", "#e8e8e8")
box(ax, 6.2, 3.8, 2.0, 1.2, "Temporal encoder\n(LSTM, 6 h window)", "#cfeccf")
box(ax, 6.2, 1.0, 2.0, 1.2, "Static encoder\n(MLP)", "#cfeccf")
box(ax, 8.9, 2.4, 1.8, 1.2, "Fusion + head\nP(spike in 2 h)", "#b8e0b8")
box(ax, 11.0, 3.9, 1.8, 1.1, "Alert engine\n+ reasons", "#f6d6e0")
box(ax, 11.0, 2.4, 1.8, 1.1, "Doctor dashboard\n(Streamlit)", "#f6d6e0")
box(ax, 11.0, 0.9, 1.8, 1.1, "What-if simulator\n(meal / walk / sleep)", "#f6d6e0")
for a in [(2.6, 4.4, 3.3, 4.4), (5.5, 4.4, 6.2, 4.4), (2.6, 1.6, 3.3, 1.6), (5.5, 1.6, 6.2, 1.6),
          (8.2, 4.2, 8.9, 3.3), (8.2, 1.8, 8.9, 2.7), (10.7, 3.0, 11.0, 4.3), (10.7, 3.0, 11.0, 3.0),
          (10.7, 2.8, 11.0, 1.5)]:
    arrow(ax, *a)
fig.tight_layout()
out = ROOT / "docs"; out.mkdir(exist_ok=True)
fig.savefig(out / "architecture.pdf"); fig.savefig(out / "architecture.png", dpi=150)
print("Saved docs/architecture.pdf")
