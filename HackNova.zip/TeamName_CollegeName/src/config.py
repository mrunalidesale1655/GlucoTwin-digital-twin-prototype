"""Central configuration for GlucoTwin."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data"
SYN = DATA / "synthetic"
PROC = DATA / "processed"
MODELS = ROOT / "models"
RESULTS = ROOT / "results"

STEP_MIN = 5          # grid resolution in minutes
STEPS_PER_DAY = 288
WINDOW = 72           # input history: 72 x 5 min = 6 hours
HORIZON = 24          # prediction horizon: 24 x 5 min = 2 hours
STRIDE = 6            # a new sample every 30 minutes
THRESH = 180.0        # spike threshold (mg/dL)

CGM_COLS = ["glucose", "hour_sin", "hour_cos"]
WEAR_COLS = ["hr", "steps", "asleep", "sleep_hours"]
DYN_COLS = CGM_COLS + WEAR_COLS
STATIC_COLS = ["age", "sex", "bmi", "hba1c", "fasting_glucose",
               "metformin", "insulin", "hypertension", "family_history"]

SEED = 42
