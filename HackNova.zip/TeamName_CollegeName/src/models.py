"""Fusion network: LSTM over dynamic window + MLP over static EHR vector."""
import numpy as np
import torch
import torch.nn as nn


class GlucoTwinNet(nn.Module):
    def __init__(self, n_dyn, n_static=0, hid=64):
        super().__init__()
        self.n_static = n_static
        self.lstm = nn.LSTM(n_dyn, hid, batch_first=True)
        if n_static:
            self.static = nn.Sequential(nn.Linear(n_static, 32), nn.ReLU())
        self.head = nn.Sequential(nn.Linear(hid + (32 if n_static else 0), 64), nn.ReLU(),
                                  nn.Dropout(0.3), nn.Linear(64, 1))

    def forward(self, xd, xs=None):
        _, (h, _) = self.lstm(xd)
        z = h[-1]
        if self.n_static:
            z = torch.cat([z, self.static(xs)], dim=1)
        return self.head(z).squeeze(1)


@torch.no_grad()
def predict_proba(model, xd, xs, bs=2048):
    model.eval()
    out = []
    for i in range(0, len(xd), bs):
        a = torch.as_tensor(xd[i:i + bs])
        b = torch.as_tensor(xs[i:i + bs]) if model.n_static else None
        out.append(torch.sigmoid(model(a, b)).numpy())
    return np.concatenate(out)
