"""Clean, align, window, split (by patient) and normalise the data."""
import json
import numpy as np
import pandas as pd
from .config import *


def clean_patient(df):
    """Sort, interpolate short CGM gaps (<=30 min), add time-of-day features."""
    df = df.sort_values("t").reset_index(drop=True).copy()
    df["glucose"] = df["glucose"].interpolate(limit=6, limit_area="inside")
    df["hr"] = df["hr"].interpolate(limit=6).bfill().ffill()
    ang = (df["t"] % STEPS_PER_DAY) / STEPS_PER_DAY * 2 * np.pi
    df["hour_sin"], df["hour_cos"] = np.sin(ang), np.cos(ang)
    return df


def make_windows(df, static_vec):
    """Sliding windows. Label = glucose crosses THRESH within the next 2 h.
    Windows that already start above THRESH are skipped (we predict ONSET)."""
    dyn = df[DYN_COLS].to_numpy(np.float32)
    g = df["glucose"].to_numpy()
    Xd, y, tte, ends = [], [], [], []
    for e in range(WINDOW, len(df) - HORIZON + 1, STRIDE):
        w, fut = dyn[e - WINDOW:e], g[e:e + HORIZON]
        if np.isnan(w).any() or np.isnan(fut).any() or g[e - 1] > THRESH:
            continue
        over = fut > THRESH
        Xd.append(w); y.append(int(over.any()))
        tte.append(int(np.argmax(over)) * STEP_MIN + STEP_MIN if over.any() else -1)
        ends.append(e)
    n = len(y)
    return (np.array(Xd, np.float32).reshape(n, WINDOW, len(DYN_COLS)),
            np.tile(static_vec, (n, 1)).astype(np.float32),
            np.array(y, np.int64), np.array(tte, np.int32), np.array(ends, np.int32))


def load_raw():
    wear = pd.read_csv(SYN / "wearable.csv")
    ehr = pd.read_csv(SYN / "ehr.csv").set_index("patient_id")
    return wear, ehr


def build_dataset(seed=SEED):
    wear, ehr = load_raw()
    pids = np.array(sorted(ehr.index))
    rng = np.random.default_rng(seed)
    rng.shuffle(pids)
    n = len(pids); a, b = int(.7 * n), int(.85 * n)
    split = {"train": pids[:a].tolist(), "val": pids[a:b].tolist(), "test": pids[b:].tolist()}

    raw = {s: dict(Xd=[], Xs=[], y=[], tte=[], pid=[], end=[]) for s in split}
    for s, plist in split.items():
        for pid in plist:
            d = clean_patient(wear[wear.patient_id == pid])
            Xd, Xs, y, tte, ends = make_windows(d, ehr.loc[pid, STATIC_COLS].to_numpy(np.float32))
            for k, v in zip(["Xd", "Xs", "y", "tte", "end"], [Xd, Xs, y, tte, ends]):
                raw[s][k].append(v)
            raw[s]["pid"].append(np.array([pid] * len(y)))
    out = {}
    for s in raw:
        for k, v in raw[s].items():
            out[f"{k}_{s}"] = np.concatenate(v)

    # Normalise with TRAIN statistics only (no leakage)
    d_mean = out["Xd_train"].reshape(-1, len(DYN_COLS)).mean(0)
    d_std = out["Xd_train"].reshape(-1, len(DYN_COLS)).std(0) + 1e-6
    s_mean, s_std = out["Xs_train"].mean(0), out["Xs_train"].std(0) + 1e-6
    for s in split:
        out[f"Xd_{s}"] = ((out[f"Xd_{s}"] - d_mean) / d_std).astype(np.float32)
        out[f"Xs_{s}"] = ((out[f"Xs_{s}"] - s_mean) / s_std).astype(np.float32)

    PROC.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(PROC / "dataset.npz", **out)
    json.dump({"split": split, "dyn_mean": d_mean.tolist(), "dyn_std": d_std.tolist(),
               "stat_mean": s_mean.tolist(), "stat_std": s_std.tolist()},
              open(PROC / "meta.json", "w"), indent=2)
    for s in split:
        y = out[f"y_{s}"]
        print(f"{s:5s}: {len(split[s]):3d} patients, {len(y):6d} windows, spike rate {y.mean():.1%}")


if __name__ == "__main__":
    build_dataset()
