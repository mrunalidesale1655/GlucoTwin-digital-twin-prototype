"""Permutation importance: how much AUROC drops when one input is shuffled."""
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from sklearn.metrics import roc_auc_score
from .config import *
from .models import predict_proba


def permutation_importance(model, ds, repeats=3, seed=0):
    rng = np.random.default_rng(seed)
    xd, xs, y = ds["Xd_test"], ds["Xs_test"], ds["y_test"]
    base = roc_auc_score(y, predict_proba(model, xd, xs))
    res = {}
    for j, name in enumerate(DYN_COLS):
        drops = []
        for _ in range(repeats):
            a = xd.copy(); a[:, :, j] = a[rng.permutation(len(a))][:, :, j]
            drops.append(base - roc_auc_score(y, predict_proba(model, a, xs)))
        res[name] = float(np.mean(drops))
    for j, name in enumerate(STATIC_COLS):
        drops = []
        for _ in range(repeats):
            b = xs.copy(); b[:, j] = b[rng.permutation(len(b)), j]
            drops.append(base - roc_auc_score(y, predict_proba(model, xd, b)))
        res[name] = float(np.mean(drops))
    return res


def plot_importance(res, path):
    items = sorted(res.items(), key=lambda kv: kv[1])
    fig, ax = plt.subplots(figsize=(7, 5))
    ax.barh([k for k, _ in items], [v for _, v in items], color="#2a7de1")
    ax.set_xlabel("AUROC drop when feature is shuffled (higher = more important)")
    ax.set_title("What drives the twin's predictions?")
    fig.tight_layout(); fig.savefig(path, dpi=150); plt.close(fig)
