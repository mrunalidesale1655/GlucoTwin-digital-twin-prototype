"""Synthetic cohort generator.

Produces (1) a static 'EHR' table and (2) 5-minute wearable/CGM time series for
each virtual patient. Physiology is a simplified, rule-based simulation:
meals raise glucose (scaled by insulin resistance), walking lowers it, short
sleep raises insulin resistance, stress raises both glucose and heart rate.
This is NOT a validated physiological model; it exists so the full pipeline can
be built and tested without restricted patient data.
"""
import numpy as np
import pandas as pd
from .config import *

GLU_PER_G = 0.9   # mg/dL peak rise per gram of carbs at insulin-resistance = 1
ACT_GLU = 5.5     # mg/dL lowering per smoothed 'active 5-min step'


def smooth(x, tau):
    k = np.exp(-np.arange(0, tau * 6) / tau)
    return np.convolve(x, k)[: len(x)]


_tt = np.arange(0, 48) * STEP_MIN
MEAL_KERNEL = _tt * np.exp(-_tt / 50.0)
MEAL_KERNEL = MEAL_KERNEL / MEAL_KERNEL.max()   # peaks ~50 min after a meal


def insulin_resistance(bmi, hba1c, metformin, insulin):
    ir = 0.8 + (bmi - 22) * 0.03 + (hba1c - 6) * 0.08
    return ir * (0.85 if metformin else 1.0) * (0.8 if insulin else 1.0)


def simulate_patient(pid, days, rng):
    n = days * STEPS_PER_DAY
    t = np.arange(n)
    hod = (t % STEPS_PER_DAY) * STEP_MIN / 60.0

    age = int(rng.integers(30, 76)); sex = int(rng.integers(0, 2))
    bmi = float(np.clip(rng.normal(27.5, 4), 18, 42))
    hba1c = float(np.clip(rng.normal(7.6, 1.2), 5.7, 12))
    insulin = int(hba1c > 8.5 and rng.random() < 0.4)
    metformin = int(rng.random() < 0.75)
    htn = int(rng.random() < np.clip(0.3 + 0.006 * (age - 40), 0, 0.9))
    fam = int(rng.random() < 0.5)
    base = 80 + (hba1c - 5.5) * 14
    ir = insulin_resistance(bmi, hba1c, metformin, insulin)

    asleep = np.zeros(n); sleep_h = np.zeros(n)
    impulse = np.zeros(n); act = np.zeros(n)
    ir_day = np.full(n, ir)
    prev_bed = 23.0
    for d in range(days):
        s = d * STEPS_PER_DAY
        wake = float(np.clip(rng.normal(6.5, 0.9), 4.5, 9))
        bed = float(np.clip(rng.normal(23.0, 1.0), 21, 23.9))
        dur = wake + (24 - prev_bed)
        asleep[s: s + int(wake * 12)] = 1
        asleep[s + int(bed * 12): s + STEPS_PER_DAY] = 1
        sleep_h[s: s + STEPS_PER_DAY] = dur
        if dur < 6:
            ir_day[s: s + STEPS_PER_DAY] = ir * 1.12
        prev_bed = bed
        for mu, sd, lo, hi, p in [(8, .6, 35, 90, 1), (13.2, .7, 60, 120, 1),
                                  (17, .6, 15, 50, .7), (20.5, .8, 55, 130, 1)]:
            if rng.random() > p:
                continue
            tm = s + int(np.clip(rng.normal(mu, sd), 6, 22.5) * 12)
            impulse[tm] += rng.uniform(lo, hi) * GLU_PER_G * ir_day[tm]
            if mu > 12 and rng.random() < 0.35:       # post-meal walk
                a = tm + int(rng.integers(1, 4))
                act[a: a + int(rng.integers(4, 9))] = 1
        for _ in range(int(rng.integers(0, 3))):       # random daytime walks
            a = s + int(rng.uniform(7, 20) * 12)
            act[a: a + int(rng.integers(3, 9))] = 1

    steps = rng.poisson(np.where((hod > 7) & (hod < 21), 40, 5)) * (1 - asleep)
    steps = steps + act * rng.normal(450, 60, n)
    stress = np.zeros(n)
    noise = np.zeros(n)
    for i in range(1, n):
        stress[i] = 0.99 * stress[i - 1] + rng.normal(0, 0.15)
        noise[i] = 0.9 * noise[i - 1] + rng.normal(0, 2.5)
    meal = np.convolve(impulse, MEAL_KERNEL)[:n]

    glucose = (base + 8 * np.exp(-0.5 * ((hod - 6.5) / 1.5) ** 2) + meal
               - ACT_GLU * smooth(act, 12) + 6 * stress + noise - 5 * asleep)
    glucose = np.clip(glucose + rng.normal(0, 1.5, n), 45, 400)
    hr = (62 + 0.3 * (bmi - 25) + 0.05 * (age - 50) + 10 * smooth(act, 3)
          + 4 * stress + 0.04 * meal - 8 * asleep + rng.normal(0, 2, n))
    for _ in range(3):                                   # CGM dropouts
        g0 = int(rng.integers(0, n - 10))
        glucose[g0: g0 + int(rng.integers(2, 10))] = np.nan

    wear = pd.DataFrame({"patient_id": pid, "t": t, "glucose": glucose.round(1),
                         "hr": hr.round(1), "steps": steps.clip(0).round(0),
                         "asleep": asleep, "sleep_hours": sleep_h.round(2)})
    ehr = dict(patient_id=pid, age=age, sex=sex, bmi=round(bmi, 1), hba1c=round(hba1c, 1),
               fasting_glucose=round(base + rng.normal(0, 5), 1), metformin=metformin,
               insulin=insulin, hypertension=htn, family_history=fam)
    return wear, ehr


def generate(n_patients=60, days=14, seed=SEED):
    rng = np.random.default_rng(seed)
    W, E = [], []
    for i in range(n_patients):
        w, e = simulate_patient(f"P{i:03d}", days, rng)
        W.append(w); E.append(e)
    SYN.mkdir(parents=True, exist_ok=True)
    pd.concat(W).to_csv(SYN / "wearable.csv", index=False)
    pd.DataFrame(E).to_csv(SYN / "ehr.csv", index=False)
    print(f"Generated {n_patients} patients x {days} days -> {SYN}")


if __name__ == "__main__":
    generate()
