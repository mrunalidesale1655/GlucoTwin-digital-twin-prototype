"""The 'digital twin' layer: patient state -> risk, plus what-if scenarios.

What-if method: roll the patient's recent window forward 30 minutes under a
scenario (meal / walk), using simple rule-based glucose/HR/steps responses
shared with the data generator, then ask the trained model for the 2-hour
spike risk. Effects are approximate, NOT a validated physiological model.
"""
import json
import numpy as np
import torch
from .config import *
from .data_gen import MEAL_KERNEL, GLU_PER_G, ACT_GLU, smooth, insulin_resistance
from .models import GlucoTwinNet, predict_proba

G, HR, ST, AS, SL = (DYN_COLS.index(c) for c in ["glucose", "hr", "steps", "asleep", "sleep_hours"])
HS, HC = DYN_COLS.index("hour_sin"), DYN_COLS.index("hour_cos")


class PatientTwin:
    def __init__(self, ckpt=MODELS / "glucotwin_full.pt", meta=PROC / "meta.json"):
        ck = torch.load(ckpt, map_location="cpu")
        self.model = GlucoTwinNet(ck["n_dyn"], ck["n_static"])
        self.model.load_state_dict(ck["state_dict"]); self.model.eval()
        self.threshold = ck["threshold"]
        m = json.load(open(meta))
        self.dm, self.ds = np.array(m["dyn_mean"], np.float32), np.array(m["dyn_std"], np.float32)
        self.sm, self.ss = np.array(m["stat_mean"], np.float32), np.array(m["stat_std"], np.float32)

    def risk(self, window, static):
        """window: raw (WINDOW, len(DYN_COLS)); static: raw (len(STATIC_COLS),)."""
        xd = ((window - self.dm) / self.ds).astype(np.float32)[None]
        xs = ((static - self.sm) / self.ss).astype(np.float32)[None]
        return float(predict_proba(self.model, xd, xs)[0])

    def roll_forward(self, window, static, carbs_g=0.0, walk_min=0, minutes=30):
        n = minutes // STEP_MIN
        w = window.copy()
        s = dict(zip(STATIC_COLS, static))
        ir = insulin_resistance(s["bmi"], s["hba1c"], s["metformin"], s["insulin"])
        act = np.zeros(len(w) + n); act[len(w): len(w) + min(n, walk_min // STEP_MIN)] = 1
        act_fx = ACT_GLU * smooth(act, 12)[len(w):]
        idx = np.arange(1, n + 1)
        meal_fx = carbs_g * GLU_PER_G * ir * MEAL_KERNEL[idx]
        last = w[-1]
        fut = np.tile(last, (n, 1))
        fut[:, G] = last[G] + meal_fx - act_fx
        fut[:, HR] = last[HR] + 10 * smooth(act, 3)[len(w):]
        fut[:, ST] = np.mean(w[-12:, ST]) + act[len(w):] * 450
        # advance clock features
        steps_ahead = idx
        base_ang = np.arctan2(last[HS], last[HC]) % (2 * np.pi)
        ang = base_ang + steps_ahead / STEPS_PER_DAY * 2 * np.pi
        fut[:, HS], fut[:, HC] = np.sin(ang), np.cos(ang)
        return np.vstack([w, fut])[-WINDOW:]

    def what_if(self, window, static, carbs_g=0.0, walk_min=0, sleep_hours=None):
        base_w = self.roll_forward(window, static)
        scen = window.copy()
        if sleep_hours is not None:
            scen[:, SL] = sleep_hours
        scen_w = self.roll_forward(scen, static, carbs_g, walk_min)
        return dict(baseline_risk=self.risk(base_w, static), scenario_risk=self.risk(scen_w, static),
                    baseline_glucose=base_w[-6:, G], scenario_glucose=scen_w[-6:, G])
