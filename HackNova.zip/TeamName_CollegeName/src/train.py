"""Training + evaluation helpers (deep fusion model and baselines)."""
import numpy as np
import torch
import torch.nn as nn
from sklearn.ensemble import HistGradientBoostingClassifier
from sklearn.metrics import (average_precision_score, brier_score_loss, precision_recall_curve,
                             precision_recall_fscore_support, roc_auc_score)
from .config import *
from .models import GlucoTwinNet, predict_proba


def load_ds():
    return dict(np.load(PROC / "dataset.npz"))


def idx_of(cols):
    return [DYN_COLS.index(c) for c in cols]


def best_threshold(y, p):
    pr, rc, th = precision_recall_curve(y, p)
    f1 = 2 * pr * rc / (pr + rc + 1e-9)
    return float(th[np.argmax(f1[:-1])])


def metrics(y, p, thr, tte):
    pred = p >= thr
    pr, rc, f1, _ = precision_recall_fscore_support(y, pred, average="binary", zero_division=0)
    tp = pred & (y == 1)
    fp = pred & (y == 0)
    days = len(y) * STRIDE * STEP_MIN / 1440.0
    return dict(AUROC=roc_auc_score(y, p), AUPRC=average_precision_score(y, p),
                Precision=pr, Recall=rc, F1=f1, Brier=brier_score_loss(y, p) if 0 <= p.min() and p.max() <= 1 else float('nan'),
                LeadTime_min=float(tte[tp].mean()) if tp.any() else float("nan"),
                FalseAlarms_per_day=float(fp.sum() / days))


def fit_deep(ds, cols, use_static, epochs=20, seed=0, verbose=True):
    torch.manual_seed(seed); np.random.seed(seed)
    ix = idx_of(cols)
    g = lambda s: (ds[f"Xd_{s}"][:, :, ix], ds[f"Xs_{s}"], ds[f"y_{s}"])
    (xtr, str_, ytr), (xva, sva, yva), (xte, ste, yte) = g("train"), g("val"), g("test")
    model = GlucoTwinNet(len(ix), str_.shape[1] if use_static else 0)
    opt = torch.optim.Adam(model.parameters(), lr=1e-3, weight_decay=1e-5)
    pw = torch.tensor((1 - ytr.mean()) / ytr.mean(), dtype=torch.float32)
    lossf = nn.BCEWithLogitsLoss(pos_weight=pw)
    Xt, St, Yt = map(torch.as_tensor, (xtr, str_, ytr.astype(np.float32)))
    best, best_state, bad = -1, None, 0
    for ep in range(epochs):
        model.train()
        perm = torch.randperm(len(Xt))
        for i in range(0, len(perm), 256):
            b = perm[i:i + 256]
            opt.zero_grad()
            loss = lossf(model(Xt[b], St[b] if use_static else None), Yt[b])
            loss.backward(); opt.step()
        auc = roc_auc_score(yva, predict_proba(model, xva, sva))
        if verbose:
            print(f"    epoch {ep + 1:2d}  val AUROC {auc:.4f}")
        if auc > best:
            best, bad = auc, 0
            best_state = {k: v.clone() for k, v in model.state_dict().items()}
        else:
            bad += 1
            if bad >= 4:
                break
    model.load_state_dict(best_state)
    thr = best_threshold(yva, predict_proba(model, xva, sva))
    pte = predict_proba(model, xte, ste)
    return model, thr, metrics(yte, pte, thr, ds["tte_test"]), pte


# ---------------- baselines ----------------
def baseline_persistence(ds):
    """Rule: score = current glucose + 3 x (30-min slope). Needs no training."""
    sc = lambda s: ds[f"Xd_{s}"][:, -1, 0] + 3 * (ds[f"Xd_{s}"][:, -1, 0] - ds[f"Xd_{s}"][:, -7, 0])
    thr = best_threshold(ds["y_val"], sc("val"))
    return metrics(ds["y_test"], sc("test"), thr, ds["tte_test"])


def _tab(x, s, use_static):
    f = [x[:, -1], x.mean(1), x.std(1), x.min(1), x.max(1), x[:, -1] - x[:, -7], x[:, -1] - x[:, -13]]
    if use_static:
        f.append(s)
    return np.concatenate(f, axis=1)


def baseline_gbm(ds, use_static=True):
    """Gradient boosting on hand-crafted summary features (all channels)."""
    g = lambda s: _tab(ds[f"Xd_{s}"], ds[f"Xs_{s}"], use_static)
    clf = HistGradientBoostingClassifier(max_iter=250, learning_rate=0.06,
                                         class_weight="balanced", random_state=0)
    clf.fit(g("train"), ds["y_train"])
    thr = best_threshold(ds["y_val"], clf.predict_proba(g("val"))[:, 1])
    return metrics(ds["y_test"], clf.predict_proba(g("test"))[:, 1], thr, ds["tte_test"])
