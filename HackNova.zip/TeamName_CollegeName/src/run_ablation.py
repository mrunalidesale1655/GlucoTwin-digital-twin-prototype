"""Train all variants + baselines, write the ablation table, save the best model."""
import json
import pandas as pd
import torch
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from .config import *
from .train import load_ds, fit_deep, baseline_persistence, baseline_gbm
from .explain import permutation_importance, plot_importance

VARIANTS = {
    "CGM only (LSTM)":          (CGM_COLS, False),
    "CGM + wearables (LSTM)":   (CGM_COLS + WEAR_COLS, False),
    "CGM + static EHR (LSTM)":  (CGM_COLS, True),
    "FULL FUSION (LSTM+EHR)":   (CGM_COLS + WEAR_COLS, True),
}


def main(epochs=20):
    RESULTS.mkdir(exist_ok=True); MODELS.mkdir(exist_ok=True)
    ds = load_ds()
    rows = {"Baseline A: persistence rule": baseline_persistence(ds),
            "Baseline B: GBM (all features)": baseline_gbm(ds)}
    print("Baselines done")
    full = None
    for name, (cols, use_static) in VARIANTS.items():
        print(f"Training: {name}")
        model, thr, m, _ = fit_deep(ds, cols, use_static, epochs=epochs)
        rows[name] = m
        if name.startswith("FULL"):
            full = (model, thr)
    df = pd.DataFrame(rows).T.round(3)
    df.to_csv(RESULTS / "ablation.csv")
    (RESULTS / "ablation.md").write_text(df.to_markdown())
    print("\n", df.to_string())

    fig, ax = plt.subplots(figsize=(9, 4.5))
    df["AUROC"].plot.barh(ax=ax, color=["#bbb", "#bbb", "#8fb8ee", "#8fb8ee", "#8fb8ee", "#1f6fd1"])
    ax.set_xlim(0.5, 1.0); ax.set_xlabel("Test AUROC (unseen patients)")
    ax.set_title("Ablation: does fusing EHR + wearables help?")
    fig.tight_layout(); fig.savefig(RESULTS / "ablation.png", dpi=150); plt.close(fig)

    model, thr = full
    torch.save({"state_dict": model.state_dict(), "n_dyn": len(DYN_COLS), "n_static": len(STATIC_COLS),
                "threshold": thr}, MODELS / "glucotwin_full.pt")
    imp = permutation_importance(model, ds)
    plot_importance(imp, RESULTS / "importance.png")
    json.dump(imp, open(RESULTS / "importance.json", "w"), indent=2)
    print("Saved model, ablation table/plot, importance plot.")


if __name__ == "__main__":
    main()
